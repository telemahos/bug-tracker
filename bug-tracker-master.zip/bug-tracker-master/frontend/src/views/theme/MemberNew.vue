<template>
  <h1>This is MemberNew Page!</h1>
</template>

<script>
export default {
  name: 'MemberNew',
}
</script>
