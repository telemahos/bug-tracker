<CRow>
    <CCol>
      <CCard class="mb-4">
        <CCardHeader> Projects </CCardHeader>
        <CCardBody>
          <p>
            Documentation and examples for Bootstrap typography, including
            global settings, headings, body text, lists, and more.
          </p>
          <CTable>
            <CTableHead>
              <CTableRow>
                <CTableHeaderCell>Heading</CTableHeaderCell>
                <CTableHeaderCell>Example</CTableHeaderCell>
              </CTableRow>
            </CTableHead>
            <CTableBody>
              <CTableRow>
                <CTableDataCell>
                  <p>
                    
                  </p>
                </CTableDataCell>
                <CTableDataCell
                  ><span class="h1">h1. Bootstrap heading</span></CTableDataCell
                >
              </CTableRow>
              <CTableRow>
                <CTableDataCell>
                  <p>
                    
                  </p>
                </CTableDataCell>
                <CTableDataCell><span class="h2">h2. Bootstrap heading</span></CTableDataCell>
              </CTableRow>
              <CTableRow>
                <CTableDataCell>
                  <p>
                    
                  </p>
                </CTableDataCell>
                <CTableDataCell><span class="h3">h3. Bootstrap heading</span></CTableDataCell>
              </CTableRow>
              <CTableRow>
                <CTableDataCell>
                  <p>
                    
                  </p>
                </CTableDataCell>
                <CTableDataCell><span class="h4">h4. Bootstrap heading</span></CTableDataCell>
              </CTableRow>
              <CTableRow>
                <CTableDataCell>
                  <p>
                    
                  </p>
                </CTableDataCell>
                <CTableDataCell><span class="h5">h5. Bootstrap heading</span></CTableDataCell>
              </CTableRow>
              <CTableRow>
                <CTableDataCell>
                  <p>
                    
                  </p>
                </CTableDataCell>
                <CTableDataCell><span class="h6">h6. Bootstrap heading</span></CTableDataCell>
              </CTableRow>
            </CTableBody>
          </CTable>
        </CCardBody>
      </CCard>
      <CCard class="mb-4">
        <CCardHeader> Tickets </CCardHeader>
        <CCardBody>
          <p>
            
          </p>
          
          
        </CCardBody>
      </CCard>
      <CCard class="mb-4">
        <CCardHeader> Teams </CCardHeader>
        <CCardBody>
          <p>
            Traditional heading elements are designed to work best in the meat
            of your page content. When you need a heading to stand out, consider
            using a <strong>display heading</strong>—a larger, slightly more
            opinionated heading style.
          </p>
          
        </CCardBody>
      </CCard>
      <CCard class="mb-4">
        <CCardHeader> Stats </CCardHeader>
        <CCardBody>
          <p>
            Traditional heading elements are designed to work best in the meat
            of your page content. When you need a heading to stand out, consider
            using a <strong>display heading</strong>—a larger, slightly more
            opinionated heading style.
          </p>
          
        </CCardBody>
      </CCard>
    </CCol>
  </CRow>
