<template>
  <h1>This is MemberProfile Page!</h1>
</template>

<script>
export default {
  name: 'MemberProfile',
}
</script>
