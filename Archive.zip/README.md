# Bug Tracker Project #

This Project is based on **Python FASTAPI** as backend framework, **SQLite** for data storage and **Vue.js** as frontend framework!

### About ###

With this web application, projects can be created, that includes tickets from teams with several members and different user roles. Any User can track the progress of a *Bug* or an *Issue*, within a project.    
